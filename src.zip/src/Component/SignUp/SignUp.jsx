import React from "react";

const SignUp = () =>{
    return(
        <div>Welcome to the SignUp Page</div>
    )

} 

export default SignUp;