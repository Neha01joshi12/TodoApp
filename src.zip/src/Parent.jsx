import React from "react";

const Parent = () =>{
    return(
        <div></div>
    )

} 

export default Parent;